## Baselines for grid dispatching competition

Competition link: [国家电网调控AI创新大赛：电网运行组织智能安排](https://aistudio.baidu.com/aistudio/competition/detail/111)

We provide a distributed SAC baseline based on PARL with paddlepaddle or torch:
- [paddlepaddle baseline](paddle)
- [torch baseline](torch)
